---
name: Bengal Voyager
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3f4944'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6f7a73'
  outline-variant: '#bec9c2'
  surface-tint: '#046c50'
  primary: '#00503a'
  on-primary: '#ffffff'
  primary-container: '#006a4e'
  on-primary-container: '#92e7c3'
  inverse-primary: '#83d7b4'
  secondary: '#bb0027'
  on-secondary: '#ffffff'
  secondary-container: '#e41b38'
  on-secondary-container: '#fffbff'
  tertiary: '#344467'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c5c80'
  on-tertiary-container: '#c5d5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ef4d0'
  primary-fixed-dim: '#83d7b4'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b1'
  on-secondary-fixed: '#410007'
  on-secondary-fixed-variant: '#92001c'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#b6c6f0'
  on-tertiary-fixed: '#071b3b'
  on-tertiary-fixed-variant: '#364669'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1280px
  gutter: 16px
---

## Brand & Style

The design system is engineered to facilitate a seamless, secure, and vibrant travel experience across Bangladesh. The brand personality balances the nation's energetic spirit with a deep sense of institutional reliability. It aims to evoke an emotional response of "confident exploration"—making the user feel both excited about the destination and safe in the logistics.

The aesthetic follows a **Modern Corporate** style infused with **Vibrant Accents**. This approach utilizes heavy whitespace and a clean, structured layout to ensure high utility, while leveraging the bold colors of the national identity to create cultural resonance. The UI feels premium and "tech-forward," moving away from cluttered traditional travel portals toward a streamlined, service-oriented interface.

## Colors

This design system uses a high-contrast palette designed for clarity and cultural impact.
- **Primary Green (#006A4E):** Reserved for growth, success states, and primary navigation elements. It represents the lush landscape of Bangladesh.
- **Secondary Red (#F42A41):** Used sparingly for high-energy accents, live indicators, and critical emergency UI elements.
- **Deep Navy (#1A2B4C):** The "Trust" anchor. Used for headings, primary text, and professional surfaces to ground the more vibrant colors.
- **Backgrounds:** A crisp white (#FFFFFF) is the primary surface, with a light gray (#F8F9FA) used for secondary containers to provide subtle depth without clutter.

## Typography

The typography strategy employs a pairing of **Plus Jakarta Sans** for headlines and **Inter** for all functional UI and body text. 

Plus Jakarta Sans provides a soft, welcoming, and modern geometric feel for travel discovery and marketing sections. Inter is utilized for its exceptional legibility in data-heavy views, such as booking confirmations and transport schedules. 

Hierarchy is established through weight variation rather than excessive size changes. Use Navy (#1A2B4C) for all primary headlines to ensure a sense of authority and professional stability.

## Layout & Spacing

This design system relies on a **Fluid Grid** model based on an 8px square rhythm. 

- **Mobile:** 4-column grid with 16px side margins and 16px gutters.
- **Tablet:** 8-column grid with 24px side margins.
- **Desktop:** 12-column grid with a maximum container width of 1280px, centered on the viewport.

Spacing should be used to create clear logical groupings. Components like cards should use `lg` (24px) padding for content internally to maintain a spacious, premium feel. Vertical stack spacing between distinct content sections should default to `xl` (40px) to allow the UI to "breathe."

## Elevation & Depth

Visual hierarchy is managed through **Tonal Layers** and **Ambient Shadows**. 

1.  **Level 0 (Base):** Light Gray (#F8F9FA) background.
2.  **Level 1 (Cards/Surface):** Pure White (#FFFFFF) with a soft, diffused shadow (0px 4px 12px rgba(26, 43, 76, 0.05)).
3.  **Level 2 (Overlays/Floating):** Pure White with a more pronounced shadow (0px 12px 24px rgba(26, 43, 76, 0.12)).

To maintain a modern feel, avoid heavy black shadows. Instead, use shadows tinted with the Navy tertiary color to keep the depth feeling natural and integrated into the color palette.

## Shapes

The shape language is defined by **Rounded** geometry to evoke friendliness and approachability. 

- **Standard Elements:** Buttons, input fields, and small tags use a 0.5rem (8px) corner radius.
- **Large Elements:** Content cards and feature banners use `rounded-lg` (1rem/16px) or `rounded-xl` (1.5rem/24px) to create a distinct, modern "app-like" container feel.
- **Selection States:** Radio buttons remain circular, while checkboxes use a 4px radius to match the overall softness of the design system.

## Components

### Buttons
- **Primary:** Solid Green (#006A4E) with White text. Bold, high-contrast, for the main user objective.
- **Emergency:** Solid Red (#F42A41) with White text. Utilizes a pulse animation or high-contrast border in specific high-stress contexts (e.g., "Call Support").
- **Secondary:** Navy (#1A2B4C) outline with Navy text for professional, non-primary actions.

### Cards
Travel destination cards should feature high-quality imagery with a gradient overlay (bottom-to-top, Navy to transparent) to allow white typography to sit legibly over the photo. All cards use Level 1 elevation.

### Input Fields
Outlined style using a light stroke of Navy at 20% opacity. Upon focus, the stroke becomes the Primary Green at 100% opacity with a subtle 2px outer glow.

### Emergency UI
Specific "Help" or "SOS" components must use the Secondary Red. These components should bypass standard padding rules to appear pinned or persistent in high-stress user flows (e.g., during active travel).

### Status Chips
- **Confirmed:** Soft Green background with Deep Green text.
- **Pending:** Soft Blue background with Navy text.
- **Alert:** Soft Red background with Deep Red text.